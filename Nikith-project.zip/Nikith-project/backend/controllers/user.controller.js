const users = require("../data/users");
const { v4: uuid } = require("uuid");

exports.getAllUsers = async (req, res) => {
  res.status(200).json(users);
};

exports.getUserById = async (req, res) => {
  const user = users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }
  res.json(user);
};

exports.createUser = async (req, res) => {
  const { name, email, role } = req.body;

  if (!name || !email || !role) {
    return res.status(400).json({ message: "Missing fields" });
  }

  const newUser = { id: uuid(), name, email, role };
  users.push(newUser);
  res.status(201).json(newUser);
};

exports.updateUser = async (req, res) => {
  const user = users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  Object.assign(user, req.body);
  res.json(user);
};

exports.deleteUser = async (req, res) => {
  const index = users.findIndex((u) => u.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: "User not found" });
  }

  users.splice(index, 1);
  res.status(204).send();
};
