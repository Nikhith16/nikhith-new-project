import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  users: any[] = [];

  user = {
    name: '',
    email: '',
    role: '',
  };

  constructor(private service: UserService) {}

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    this.service.getUsers().subscribe((data) => {
      this.users = data;
    });
  }

  save() {
    this.service.createUser(this.user).subscribe(() => {
      this.user = { name: '', email: '', role: '' };
      this.loadUsers();
    });
  }

  delete(id: string) {
    this.service.deleteUser(id).subscribe(() => {
      this.loadUsers();
    });
  }
}
