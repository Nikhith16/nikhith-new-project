import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private api = 'http://localhost:3000/api/users';

  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get<any[]>(this.api);
  }

  createUser(user: any) {
    return this.http.post(this.api, user);
  }

  deleteUser(id: string) {
    return this.http.delete(`${this.api}/${id}`);
  }
}
