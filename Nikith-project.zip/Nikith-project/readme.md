steps to run:
frontend:
npm i
ng serve

backend:
npm i
npm run dev

then try to access: http://localhost:4200/

name of submitter: nikhith reddy pathuri
email: pathurinikhithreddy@gmail.com
contact: 9802242213
